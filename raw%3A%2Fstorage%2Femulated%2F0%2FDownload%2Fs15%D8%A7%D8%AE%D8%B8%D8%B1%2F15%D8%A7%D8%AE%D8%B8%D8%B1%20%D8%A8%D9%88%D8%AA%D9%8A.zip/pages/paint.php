
<div class="scroll-other">
<div class="balance paint-1 kiri" onclick="openOther(event, 'paint1');" id="defaultTabOther">
<div class="balance-name">5 Unit</div>
<div class="balance-total">Free</div>
</div>
<div class="balance paint-1 kanan" onclick="openOther(event, 'paint2');">
<div class="balance-name">10 Unit</div>
<div class="balance-total">Free</div>
</div>
<div class="balance paint-2 kiri" onclick="openOther(event, 'paint3');">
<div class="balance-name">13 Unit</div>
<div class="balance-total">Free</div>
</div>
<div class="balance paint-2 kanan" onclick="openOther(event, 'paint4');">
<div class="balance-name">15 Unit</div>
<div class="balance-total">Free</div>
</div>
<div class="balance paint-3 kiri" onclick="openOther(event, 'paint5');">
<div class="balance-name">18 Unit</div>
<div class="balance-total">Free</div>
</div>
<div class="balance paint-3 kanan" onclick="openOther(event, 'paint6');">
<div class="balance-name">20 Unit</div>
<div class="balance-total">Free</div>
</div>
</div>
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5dcbabd2869127ad"></script>
<a href="javascript:;" onclick="buka('pages/material');"><button type="button" class="balance-change kiri">Material <i class="fa fa-chevron-left previous"></i></button></a>
<a href="javascript:;" onclick="buka('pages/weapon');"><button type="button" class="balance-change kanan">Weapon <i class="fa fa-chevron-right next"></i></button></a>

<center>
<div id="paint1" class="tab_other">
<button type="button" class="balance-collect" onclick="login()">Collect <i class="fa fa-chevron-right"></i></button>
</div>
<div id="paint2" class="tab_other">
<button type="button" class="balance-collect" onclick="login()">Collect <i class="fa fa-chevron-right"></i></button>
</div>
<div id="paint3" class="tab_other">
<button type="button" class="balance-collect" onclick="login()">Collect <i class="fa fa-chevron-right"></i></button>
</div>
<div id="paint4" class="tab_other">
<button type="button" class="balance-collect" onclick="login()">Collect <i class="fa fa-chevron-right"></i></button>
</div>
<div id="paint5" class="tab_other">
<button type="button" class="balance-collect" onclick="login()">Collect <i class="fa fa-chevron-right"></i></button>
</div>
<div id="paint6" class="tab_other">
<button type="button" class="balance-collect" onclick="login()">Collect <i class="fa fa-chevron-right"></i></button>
</div>
</center>

<script type="text/javascript" src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="js/tab_other.js"></script>
<script src="js/popup.js"></script>